<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="index.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-sm bg-warning navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#" style="font-size: xx-large;"><img src="burger3.png" style=" width: 7%;"> EL CUARTEL</a>
  </div>
</nav>
<div class="form1">
<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
   Tipo de Hamburguesa <select name="tipo">
    <option>Cuartel</option>
    <option> Todoterreno</option>
    </select>

  
   
    <br>
    <div class="check">
        <label >
    <input type="checkbox" name="Tocineta" > Tocineta <img src="tocineta1.png">
        </label>
        <label>
    <input type="checkbox" name="Queso"> Queso <img src="queso2.png">
    </label>
    <label>
    <input type="checkbox" name="Cebolla"> Cebolla grille <img src="cebolla4.png" style="width: 40%;">
    </label>
    
</div>
<div class="boton">
   <input type="submit">
    
   </div>
   </form> 
</div>
<div class="precio">
<?php



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require "Clases.php";
$tipo = $_POST['tipo'];
$burger = null;
if ($tipo == "Cuartel"){
    $burger= new Cuartel();
}else{
    $burger = new Todoterreno();
}

if (isset($_POST['Tocineta'])){
    $burger = new Tocineta ($burger);
}
if (isset($_POST['Queso'])){
    $burger = new Queso ($burger);
}
if (isset($_POST['Cebolla'])){
    $burger = new Cebolla ($burger);
}
echo"La ". $burger->getDescripion() . " vale " . $burger->getPrecio();
if ($tipo == "Cuartel"){
    echo "<br><img src='burger1.png'>";
}else{
    echo "<br><img src='burger2.png'>";
}
}
?>
</div>

</body>
</html>